using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour
{
    public AudioClip hitSound;
    public AudioClip bgSound;
    public AudioSource audioSource;
    // Start is called before the first frame update
    void Start()
    {
        audioSource = GetComponent<AudioSource>();
    }
    private void FixedUpdate()
    {

    }
    public void PlayHitSound()
    {
        audioSource.PlayOneShot(hitSound);
    }
    public void BGSound()
    {
        audioSource.PlayOneShot(bgSound);
    }
    // Update is called once per frame
    void Update()
    {

    }
}
